export function Account(){
    return(
        <h1>Account Detail</h1>
    )
}