
export function Vendor(){
    return (
        <h1>Vendor Foam</h1>
    )
}