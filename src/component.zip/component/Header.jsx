
export  function Header(){
    return(
        <header className='heading'>Account Mangement Systom</header>
    )
}