
export function Contact(){
    return(
        <h1>Contact US me</h1>
    )
}