
export function Home(){
    return(
        <h1>Home a</h1>
    )
}