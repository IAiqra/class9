export function VendorDetail() {
    return(
        <h1>Vendor Detail</h1>
    )
}