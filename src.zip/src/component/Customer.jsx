
export function Customer(){
    return(
        <h1>Customer Foam</h1>
    )
}